import React, { useContext, useEffect } from 'react';
import { StickerCartContext } from '../contexts/stickerCartContext';
import { IoTrashBin } from "react-icons/io5";
import './CSS/Cart.css';

const Cart = () => {
  const { basket, setBasket } = useContext(StickerCartContext);
  function deleteFromCart(ID) {
    // basket.map(item=> console.log(item))
    console.log(ID);
    setBasket(basket.filter(element => element.item.id !== ID));
    localStorage.setItem("basket", JSON.stringify(basket))
    console.log(basket);
  }
  return (
    <div id='cart'>
      <div className="container">
        <div className='cartBody'>
          <h1>Your Cart</h1>
          <table class="mx-auto">
            <thead>
              <tr class="uppercase text-xs sm:text-sm text-palette-primary border-b border-palette-light">
                <th class="font-primary font-normal px-6 py-4">Product</th>
                <th class="font-primary font-normal px-6 py-4">Quantity</th>
                <th class="font-primary font-normal px-6 py-4 hidden sm:table-cell">Price</th>
                <th class="font-primary font-normal px-6 py-4">Remove</th>
              </tr>
            </thead>
            <tbody >
              {basket?.map((item, index) => {
                let sizeIndex;
                item?.item?.variants?.edges?.forEach((element, indexEdges) => {
                  if (item.size == element.node.title) {
                    sizeIndex = indexEdges;
                    console.log(sizeIndex);
                  }

                })
                return <tr >
                  <td >
                    <img src={item.item.images.edges[0].node.originalSrc} alt="test-text" height="64" width="64" class="hidden sm:inline-flex" />
                    <a >{item.item.title} {item.size}</a>
                  </td>
                  <td >
                    <input type="number" inputmode="numeric" value={item.quantity} />
                  </td>
                  <td >
                    $<span>{item.item.variants.edges[sizeIndex].node.price}</span>
                  </td>
                  <td>
                    <button onClick={() => { deleteFromCart(item.item.variants.edges[sizeIndex].node.id) }} aria-label="delete-item" >
                      <IoTrashBin />
                    </button>
                  </td>
                </tr>
              })}


            </tbody>
          </table>
        </div>


      </div>
    </div>
  )
}

export default Cart